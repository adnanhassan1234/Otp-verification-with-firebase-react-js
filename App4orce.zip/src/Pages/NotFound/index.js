import React from "react";

const NotFound = () => {
  return <div>Sorry, this page is not found</div>;
};

export default NotFound;
